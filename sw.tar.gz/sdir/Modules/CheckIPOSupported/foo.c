int foo(void)
{
  return 0x42;
}
